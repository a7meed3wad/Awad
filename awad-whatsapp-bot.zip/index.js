
const venom = require('venom-bot');

venom
  .create()
  .then((client) => start(client))
  .catch((erro) => {
    console.log(erro);
  });

function start(client) {
  client.onMessage((message) => {
    if (message.body === 'مرحبا' && message.isGroupMsg === false) {
      client
        .sendText(message.from, 'أهلاً وسهلاً بك في مؤسسة العوض الدولية. كيف يمكنني مساعدتك؟\n\n- 1. دوراتنا التدريبية\n- 2. التسجيل\n- 3. الدعم الفني')
        .then((result) => {
          console.log('Result: ', result);
        })
        .catch((erro) => {
          console.error('Error when sending: ', erro);
        });
    }
  });
}
